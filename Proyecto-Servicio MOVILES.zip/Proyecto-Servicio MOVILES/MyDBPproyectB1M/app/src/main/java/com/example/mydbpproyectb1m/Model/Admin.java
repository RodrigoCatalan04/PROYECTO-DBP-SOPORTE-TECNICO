package com.example.mydbpproyectb1m.Model;

public class Admin {
    private int IdAdmin;
    private String Usuario;
    private String Contraseña;

    public Admin(int idAdmin, String usuario, String contraseña) {
        IdAdmin = idAdmin;
        Usuario = usuario;
        Contraseña = contraseña;
    }

    public Admin() {
    }

    public int getIdAdmin() {
        return IdAdmin;
    }

    public void setIdAdmin(int idAdmin) {
        IdAdmin = idAdmin;
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String usuario) {
        Usuario = usuario;
    }

    public String getContraseña() {
        return Contraseña;
    }

    public void setContraseña(String contraseña) {
        Contraseña = contraseña;
    }
}
