package com.example.mydbpproyectb1m.Activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mydbpproyectb1m.Api.ServiceAPI;
import com.example.mydbpproyectb1m.Model.Servicio;
import com.example.mydbpproyectb1m.Model.Soporte;
import com.example.mydbpproyectb1m.R;
import com.example.mydbpproyectb1m.Util.ConnectionREST;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListarAgregarServicio extends AppCompatActivity {

    private EditText lstServicio;
    private EditText _etDesSer;
    private EditText _etMonSer;
    private EditText _etNumber;
    private Button btnBuscar;
    private ServiceAPI serviceAPI;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_agregar_servicio);
        lstServicio = (EditText) findViewById(R.id.lstServicio);
        serviceAPI = ConnectionREST.getConnection().create(ServiceAPI.class);

        Cargar();

        btnBuscar = (Button) findViewById(R.id.btnBuscar);
        btnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buscarServicio(Integer.parseInt(_etNumber.getText().toString()));
            }
        });
    }

    public void Cargar()
    {
        Call<List<Servicio>> lst = serviceAPI.lstServicio();
        lst.enqueue(new Callback<List<Servicio>>() {
            @Override
            public void onResponse(Call<List<Servicio>> call, Response<List<Servicio>> response) {
                if(response.isSuccessful())
                {
                    List<Servicio> lst = response.body();
                    lstServicio.setText("\n");
                    for(Servicio x:lst)
                    {
                        lstServicio.append("Id Servicio:"+x.getIdServicio()+"\n"+"Desc. Servicio:"+x.getDescripcionServicio()+"\n"+"Monto Servicio:"+x.getMontoServicio()+"\n\n\n");
                    }

                }
                else
                {
                    Toast.makeText(null, "PAPeado", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<List<Servicio>> call, Throwable t) {
                Toast.makeText(null, "Papeado", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void buscarServicio(int cod){
        Call<Servicio> call = serviceAPI.searchServiciobyId(cod);
        call.enqueue(new Callback<Servicio>() {
            @Override
            public void onResponse(Call<Servicio> call, Response<Servicio> response) {
                if(response.isSuccessful())
                {
                    Servicio obj = response.body();
                   //editText.setText(obj.getDescripcionServicio());
                    mensaje("El servicio fue encontrado");
                    Intent i = new Intent(ListarAgregarServicio.this, EliminarServicio.class);
                    startActivity(i);
                    i.putExtra("DescripcionServicio", obj.getDescripcionServicio());
                    i.putExtra("MontoServicio", obj.getMontoServicio());
                    i.putExtra("IdServicio", obj.getIdServicio());
                }
                else
                {
                    mensaje("El servicio no pudo ser encontrado");
                }

            }

            @Override
            public void onFailure(Call<Servicio> call, Throwable t) {
                mensaje("Ocurrio un error desconocido" + t.getMessage());
            }
        });
    }
    public void mensaje(String msg)
    {
        AlertDialog.Builder alerta = new AlertDialog.Builder(this);
        alerta.setMessage(msg);
        alerta.show();
    }


}