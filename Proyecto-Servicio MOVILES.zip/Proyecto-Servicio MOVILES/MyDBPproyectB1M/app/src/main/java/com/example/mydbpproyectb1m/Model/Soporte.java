package com.example.mydbpproyectb1m.Model;

public class Soporte {
    private int idSoporte;
    private float montoSoporte;
    private String descripcionSoporte;
    private int idCliente;
    private int idEquipo;
    private int idServicio;
    private String estadoSoporte;
    private String Solucion;

    public Soporte() {
    }

    public int getIdSoporte() {
        return idSoporte;
    }

    public void setIdSoporte(int idSoporte) {
        this.idSoporte = idSoporte;
    }

    public float getMontoSoporte() {
        return montoSoporte;
    }

    public void setMontoSoporte(float montoSoporte) {
        this.montoSoporte = montoSoporte;
    }

    public String getDescripcionSoporte() {
        return descripcionSoporte;
    }

    public void setDescripcionSoporte(String descripcionSoporte) {
        this.descripcionSoporte = descripcionSoporte;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public int getIdEquipo() {
        return idEquipo;
    }

    public void setIdEquipo(int idEquipo) {
        this.idEquipo = idEquipo;
    }

    public int getIdServicio() {
        return idServicio;
    }

    public void setIdServicio(int idServicio) {
        this.idServicio = idServicio;
    }

    public String getEstadoSoporte() {
        return estadoSoporte;
    }

    public void setEstadoSoporte(String estadoSoporte) {
        this.estadoSoporte = estadoSoporte;
    }

    public String getSolucion() {
        return Solucion;
    }

    public void setSolucion(String solucion) {
        Solucion = solucion;
    }
}
