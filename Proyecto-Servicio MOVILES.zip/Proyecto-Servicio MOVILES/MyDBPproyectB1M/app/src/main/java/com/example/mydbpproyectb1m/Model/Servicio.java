package com.example.mydbpproyectb1m.Model;

public class Servicio {
    private int idServicio;
    private String descripcionServicio;
    private float montoServicio;

    public Servicio(int idServicio, String descripcionServicio, float montoServicio) {
        this.idServicio = idServicio;
        this.descripcionServicio = descripcionServicio;
        this.montoServicio = montoServicio;
    }

    public Servicio() {
    }

    public int getIdServicio() {
        return idServicio;
    }

    public void setIdServicio(int idServicio) {
        this.idServicio = idServicio;
    }

    public String getDescripcionServicio() {
        return descripcionServicio;
    }

    public void setDescripcionServicio(String descripcionServicio) {
        this.descripcionServicio = descripcionServicio;
    }

    public float getMontoServicio() {
        return montoServicio;
    }

    public void setMontoServicio(float montoServicio) {
        this.montoServicio = montoServicio;
    }
}
