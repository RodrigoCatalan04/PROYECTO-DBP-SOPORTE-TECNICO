package com.example.mydbpproyectb1m.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mydbpproyectb1m.Api.ServiceAPI;
import com.example.mydbpproyectb1m.Model.Soporte;
import com.example.mydbpproyectb1m.R;
import com.example.mydbpproyectb1m.Util.ConnectionREST;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListaSoporte extends AppCompatActivity {

    private EditText lstSoporte;
    private ServiceAPI serviceAPI;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_soporte);
        lstSoporte = (EditText) findViewById(R.id.lstSoporte);
        serviceAPI = ConnectionREST.getConnection().create(ServiceAPI.class);

        Cargar();
    }

    public void Cargar()
    {
        Call<List<Soporte>> lst = serviceAPI.listSoporte();
        lst.enqueue(new Callback<List<Soporte>>() {
            @Override
            public void onResponse(Call<List<Soporte>> call, Response<List<Soporte>> response) {
                if(response.isSuccessful())
                {
                    List<Soporte> lst = response.body();
                    lstSoporte.setText("\n");
                    for(Soporte x:lst)
                    {
                        lstSoporte.append("Id Soporte:"+x.getIdSoporte()+"\n"+"Desc. Soporte:"+x.getDescripcionSoporte()+"\n"+"Monto Soporte:"+x.getMontoSoporte()+"\n"+"Id Cliente:"+x.getIdCliente()+"\n"+"Id Servicio:"+x.getIdServicio()+"\n"+"Id Equipo:"+x.getIdEquipo()+"\n"+"Estado Soporte"+x.getEstadoSoporte()+"\n"+"Solucion:"+x.getSolucion()+"\n\n\n");
                    }

                }
                else
                {
                    Toast.makeText(null, "PAPeado", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<List<Soporte>> call, Throwable t) {
                Toast.makeText(null, "Papeado", Toast.LENGTH_LONG).show();
            }
        });
    }


}