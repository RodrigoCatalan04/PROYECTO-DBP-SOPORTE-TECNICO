package com.example.mydbpproyectb1m.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.mydbpproyectb1m.R;

public class ServicioActivity extends AppCompatActivity {

    private Button btnAgregarListarServicio;
    private Button btnEliminarServicio;
    private Button btnActualizar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_servicio);

        btnAgregarListarServicio = (Button) findViewById(R.id.btnAgregarListarServicio);
        btnEliminarServicio = (Button) findViewById(R.id.btnEliminarServicio);
        btnActualizar = (Button) findViewById(R.id.btnActualizar);

        btnAgregarListarServicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ServicioActivity.this, ListarAgregarServicio.class);
                startActivity(i);
            }
        });
        btnEliminarServicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ServicioActivity.this, EliminarServicio.class);
                startActivity(i);
            }
        });
        btnActualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ServicioActivity.this, ActualizarServicio.class);
                startActivity(i);
            }
        });
    }
}