package com.example.mydbpproyectb1m.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mydbpproyectb1m.Api.ServiceAPI;
import com.example.mydbpproyectb1m.Model.Admin;
import com.example.mydbpproyectb1m.R;
import com.example.mydbpproyectb1m.Util.ConnectionREST;

import java.io.IOException;

import okhttp3.ResponseBody;


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Login extends AppCompatActivity {

    private EditText _etUser;
    private EditText _etPassword;
    private ServiceAPI serviceAPI;
    private Button _ingreso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        _etUser = (EditText) findViewById(R.id._etUser);
        _etPassword = (EditText) findViewById(R.id._etPassword);
        _ingreso = (Button) findViewById(R.id._ingreso);

        serviceAPI = ConnectionREST.getConnection().create(ServiceAPI.class);

        _ingreso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Admin objA = new Admin();
                objA.setUsuario(_etUser.getText().toString());
                objA.setContraseña(_etPassword.getText().toString());

                validarAdmin(objA);

            }
        });
    }

    public void validarAdmin(Admin admin) {
        Call<ResponseBody> call = serviceAPI.validateAdmin(admin);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    try {
                        String message = response.body().string();

                        if (message.equals("Admin válido")) {
                            // Inicio de sesión exitoso
                            Toast.makeText(Login.this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(Login.this, MainActivity.class);
                            startActivity(i);
                        } else {
                            // Usuario y/o contraseña incorrectas
                            Toast.makeText(Login.this, "Usuario y/o contraseña incorrectas", Toast.LENGTH_SHORT).show();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        Toast.makeText(Login.this, "Error al obtener la respuesta", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(Login.this, "Error en la API", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(retrofit2.Call<ResponseBody> call, Throwable t) {
                Toast.makeText(Login.this, "Error en la solicitud: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }

   });
}
}