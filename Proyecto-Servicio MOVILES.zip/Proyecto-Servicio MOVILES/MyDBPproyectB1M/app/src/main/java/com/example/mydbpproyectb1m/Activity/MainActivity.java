package com.example.mydbpproyectb1m.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mydbpproyectb1m.R;

public class MainActivity extends AppCompatActivity {

    private Button btnSoporte;
    private Button btnServicios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSoporte = (Button) findViewById(R.id.btnSoporte);
        btnServicios = (Button) findViewById(R.id.btnServicios);

        btnSoporte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, SoporteActivity.class);
                startActivity(i);
            }
        });
        btnServicios.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, ServicioActivity.class);
                startActivity(i);
            }
        });
    }

}

