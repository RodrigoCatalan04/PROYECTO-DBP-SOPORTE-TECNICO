package com.example.mydbpproyectb1m.Api;
import com.example.mydbpproyectb1m.Model.Admin;
import com.example.mydbpproyectb1m.Model.Servicio;
import com.example.mydbpproyectb1m.Model.Soporte;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface ServiceAPI {

    @GET("ListarSoporte")
    public  abstract  Call<List<Soporte>> listSoporte();
    @GET("BuscarSoporte/{id}")
    public abstract Call<Soporte> searchSoportebyId(@Path("idSoporte") int id);
    @POST("AgregarSoporte")
    public abstract Call<Soporte> addSoporte(@Body Soporte obj);
    @PUT("UpdateSoporte")
    public abstract Call<Soporte> modifySoporte(@Body Soporte obj);
    @DELETE("EliminarSoporte/{id}")
    public abstract Call<Soporte> removeSoporte(@Path("idSoporte") int id);
    @GET("ListarServicio")
    public abstract Call<List<Servicio>> lstServicio();
    @GET("BuscarServicio/{id}")
    public abstract Call<Servicio> searchServiciobyId(@Path("idServicio")int id);
    @POST("AgregarServicio")
    public abstract Call<Servicio> addServicio(@Body Servicio obj);
    @PUT("UpdateServicio/{id}")
    public abstract Call<Servicio> modifyServicio(@Body Servicio obj);
    @DELETE("EliminarServicio/{id}")
    public abstract Call<Servicio> removeServicio(@Path("idServicio") int id);
    @POST("ValidateAdmin")
    public abstract Call<ResponseBody> validateAdmin(@Body Admin obj);

}
