package com.example.mydbpproyectb1m.Activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.mydbpproyectb1m.Api.ServiceAPI;
import com.example.mydbpproyectb1m.Model.Servicio;
import com.example.mydbpproyectb1m.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EliminarServicio extends AppCompatActivity {

    private EditText _etDesc;
    private EditText _etMont;

    private EditText _etIdServicio;
    private Button btnELiminarServicio;
    private Button btnModificar;
    private ServiceAPI serviceAPI;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eliminar_servicio);
        String IDServicio= getIntent().getStringExtra("IdServicio");
        EditText _etIdServicio= findViewById(R.id._etIdServicio);
        _etIdServicio.setText(IDServicio);
        String DesServicio = getIntent().getStringExtra("DescripcionServicio");
        String MonServicio = getIntent().getStringExtra("MontoServicio");
        EditText _etDesc = findViewById(R.id._etDesc);
        _etDesc.setText(DesServicio);
        EditText _etMont = findViewById(R.id._etMont);
        _etMont.setText(MonServicio);
        btnELiminarServicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                eliminarServicio(Integer.parseInt(_etIdServicio.getText().toString()));
            }
        });
        btnModificar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                Servicio objS = new Servicio();
                objS.setDescripcionServicio(_etDesc.getText().toString());
                objS.setMontoServicio(Float.parseFloat(_etMont.getText().toString()));
                ModificarServicio(objS);
            }
        });
    }
        private void eliminarServicio(int cod) {
            Call<Servicio> call = serviceAPI.removeServicio(cod);
            call.enqueue(new Callback<Servicio>() {
                @Override
                public void onResponse(Call<Servicio> call, Response<Servicio> response) {
                    if(response.isSuccessful())
                    {
                        mensaje("El servicio fue eliminado");
                    }
                    else
                    {
                        mensaje("El servicio no pudo ser eliminado");
                    }
                }

                @Override
                public void onFailure(Call<Servicio> call, Throwable t) {
                    mensaje("Ocurrio un error desconocido" + t.getMessage());
                }
            });
        }

        public void mensaje(String msg)
        {
            AlertDialog.Builder alerta = new AlertDialog.Builder(this);
            alerta.setMessage(msg);
            alerta.show();
        }
    private void ModificarServicio(Servicio obj) {
        Call<Servicio> call = serviceAPI.modifyServicio(obj);
        call.enqueue(new Callback<Servicio>() {
            @Override
            public void onResponse(Call<Servicio> call, Response<Servicio> response) {
                if(response.isSuccessful())
                {
                    Servicio pro = response.body();

                    mensaje("El servicio fue modificado");
                }
                else
                {
                    mensaje("Ocurrio un error al modificar el servicio");
                }
            }

            @Override
            public void onFailure(Call<Servicio> call, Throwable t) {
                mensaje("Ocurrio un error desconocido" + t.getMessage());
            }
        });
    }


    }
