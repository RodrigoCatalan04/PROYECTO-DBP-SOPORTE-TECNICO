﻿using System;
using System.Collections.Generic;

namespace MYAPIDBP.Models;

public partial class Cliente
{
    public int IdCliente { get; set; }

    public string NombreCliente { get; set; } = null!;

    public string ApellidoCliente { get; set; } = null!;

    public int DniCliente { get; set; }

    public string DireccionCliente { get; set; } = null!;

    public int TelefonoCliente { get; set; }

    public string UserCliente { get; set; } = null!;

    public string PasswordCliente { get; set; } = null!;

    public virtual ICollection<Soporte> Soportes { get; set; } = new List<Soporte>();
}
