﻿using System;
using System.Collections.Generic;

namespace MYAPIDBP.Models;

public partial class Soporte
{
    public int IdSoporte { get; set; }

    public double MontoSoporte { get; set; }

    public string DescripcionSoporte { get; set; } = null!;

    public int IdCliente { get; set; }

    public int IdEquipo { get; set; }

    public int IdServicio { get; set; }

    public string EstadoSoporte { get; set; } = null!;

    public string Solucion { get; set; } = null!;

    public virtual Cliente IdClienteNavigation { get; set; } = null!;

    public virtual Equipo IdEquipoNavigation { get; set; } = null!;

    public virtual Servicio IdServicioNavigation { get; set; } = null!;
}
