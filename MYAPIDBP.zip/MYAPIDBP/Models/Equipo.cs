﻿using System;
using System.Collections.Generic;

namespace MYAPIDBP.Models;

public partial class Equipo
{
    public int IdEquipo { get; set; }

    public string DescripcionEquipo { get; set; } = null!;

    public virtual ICollection<Soporte> Soportes { get; set; } = new List<Soporte>();
}
