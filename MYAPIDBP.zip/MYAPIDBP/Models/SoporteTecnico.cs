﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace MYAPIDBP.Models;

public partial class SoporteTecnico : DbContext
{
    public SoporteTecnico()
    {
    }

    public SoporteTecnico(DbContextOptions<SoporteTecnico> options)
        : base(options)
    {
    }

    public virtual DbSet<Admin> Admins { get; set; }

    public virtual DbSet<Cliente> Clientes { get; set; }

    public virtual DbSet<Equipo> Equipos { get; set; }

    public virtual DbSet<Servicio> Servicios { get; set; }

    public virtual DbSet<Soporte> Soportes { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=sql5106.site4now.net;Initial Catalog=db_a9b31b_mobileapp12;User ID=db_a9b31b_mobileapp12_admin;Password=Rodrigo123;Integrated Security=False;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Admin>(entity =>
        {
            entity.HasKey(e => e.IdAdmin).HasName("PK__Admin__B2C3ADE554E10ED3");

            entity.ToTable("Admin");

            entity.Property(e => e.IdAdmin).HasColumnName("idAdmin");
            entity.Property(e => e.Contraseña)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("contraseña");
            entity.Property(e => e.Usuario)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("usuario");
        });

        modelBuilder.Entity<Cliente>(entity =>
        {
            entity.HasKey(e => e.IdCliente).HasName("PK__Cliente__885457EEF2EE219C");

            entity.ToTable("Cliente");

            entity.Property(e => e.IdCliente).HasColumnName("idCliente");
            entity.Property(e => e.ApellidoCliente)
                .HasMaxLength(50)
                .IsFixedLength()
                .HasColumnName("apellidoCliente");
            entity.Property(e => e.DireccionCliente)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("direccionCliente");
            entity.Property(e => e.DniCliente).HasColumnName("dniCliente");
            entity.Property(e => e.NombreCliente)
                .HasMaxLength(50)
                .IsFixedLength()
                .HasColumnName("nombreCliente");
            entity.Property(e => e.PasswordCliente)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("passwordCliente");
            entity.Property(e => e.TelefonoCliente).HasColumnName("telefonoCliente");
            entity.Property(e => e.UserCliente)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("userCliente");
        });

        modelBuilder.Entity<Equipo>(entity =>
        {
            entity.HasKey(e => e.IdEquipo).HasName("PK__Equipo__981ACF539E91C596");

            entity.ToTable("Equipo");

            entity.Property(e => e.IdEquipo).HasColumnName("idEquipo");
            entity.Property(e => e.DescripcionEquipo)
                .HasMaxLength(50)
                .IsFixedLength()
                .HasColumnName("descripcionEquipo");
        });

        modelBuilder.Entity<Servicio>(entity =>
        {
            entity.HasKey(e => e.IdServicio).HasName("PK__Servicio__CEB981193631C9BC");

            entity.ToTable("Servicio");

            entity.Property(e => e.IdServicio).HasColumnName("idServicio");
            entity.Property(e => e.DescripcionServicio)
                .HasMaxLength(50)
                .IsFixedLength()
                .HasColumnName("descripcionServicio");
            entity.Property(e => e.MontoServicio).HasColumnName("montoServicio");
        });

        modelBuilder.Entity<Soporte>(entity =>
        {
            entity.HasKey(e => e.IdSoporte).HasName("PK__Soporte__979638BA84F20164");

            entity.ToTable("Soporte");

            entity.Property(e => e.IdSoporte).HasColumnName("idSoporte");
            entity.Property(e => e.DescripcionSoporte)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("descripcionSoporte");
            entity.Property(e => e.EstadoSoporte)
                .HasMaxLength(20)
                .IsFixedLength()
                .HasColumnName("estadoSoporte");
            entity.Property(e => e.IdCliente).HasColumnName("idCliente");
            entity.Property(e => e.IdEquipo).HasColumnName("idEquipo");
            entity.Property(e => e.IdServicio).HasColumnName("idServicio");
            entity.Property(e => e.MontoSoporte).HasColumnName("montoSoporte");
            entity.Property(e => e.Solucion)
                .HasMaxLength(100)
                .IsFixedLength();

            entity.HasOne(d => d.IdClienteNavigation).WithMany(p => p.Soportes)
                .HasForeignKey(d => d.IdCliente)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Soporte_Cliente");

            entity.HasOne(d => d.IdEquipoNavigation).WithMany(p => p.Soportes)
                .HasForeignKey(d => d.IdEquipo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Soporte_Equipo");

            entity.HasOne(d => d.IdServicioNavigation).WithMany(p => p.Soportes)
                .HasForeignKey(d => d.IdServicio)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Soporte_Servicio");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
