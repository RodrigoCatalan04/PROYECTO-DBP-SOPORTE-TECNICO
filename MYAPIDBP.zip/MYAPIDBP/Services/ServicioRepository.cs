﻿using MYAPIDBP.Models;

namespace MYAPIDBP.Services
{
    public class ServicioRepository : IServicio
    {
        private SoporteTecnico conexion = new SoporteTecnico();
        public void AddServicio(Servicio servicio)
        {
            conexion.Servicios.Add(servicio);
            conexion.SaveChanges();
        }

        public void editDetails(Servicio servicio)
        {
            var ObjModificar = (from tser in conexion.Servicios
                                where tser.IdServicio == servicio.IdServicio
                                select tser).FirstOrDefault();
            ObjModificar.DescripcionServicio = servicio.DescripcionServicio;
            ObjModificar.MontoServicio = servicio.MontoServicio;
            conexion.SaveChanges();
        }

        public IEnumerable<Servicio> GetServicio()
        {
            return conexion.Servicios;
        }

        public void remove(int codigo)
        {
            var obj = ServicioById(codigo);
            conexion.Servicios.Remove(obj);
            conexion.SaveChanges();
        }

        public Servicio ServicioById(int id)
        {
            var ObjEncontrado = (from tser in conexion.Servicios
                                 where tser.IdServicio == id
                                 select tser).Single();
            return ObjEncontrado;
        }
    }
}
