﻿using MYAPIDBP.Models;

namespace MYAPIDBP.Services
{
    public interface IAdmin
    {
        public bool ValidateAdmin(Admin admin);
    }
}