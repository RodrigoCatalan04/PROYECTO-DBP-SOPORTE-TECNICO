﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using MYAPIDBP.Models;
namespace MYAPIDBP.Services
{
    public class AdminRepository : IAdmin
    {
        private SoporteTecnico conexion = new SoporteTecnico();
        public bool ValidateAdmin(Admin admin)
        {
            var obj = (from tad in conexion.Admins
                       where tad.Usuario == admin.Usuario
                       && tad.Contraseña == admin.Contraseña
                       select tad).FirstOrDefault();
            if (obj == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}