﻿using MYAPIDBP.Models;

namespace MYAPIDBP.Services
{
    public interface IServicio
    {
        public void AddServicio(Servicio servicio);
        public Servicio ServicioById(int id);
        public void editDetails(Servicio servicio);
        public IEnumerable<Servicio> GetServicio();
        public void remove(int codigo);

    }
}
