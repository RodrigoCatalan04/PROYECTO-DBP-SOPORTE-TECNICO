﻿using System;
using System.Collections.Generic;

namespace ProyectoDBP_ServicioTecnico.Models;

public partial class Servicio
{
    public int IdServicio { get; set; }

    public string DescripcionServicio { get; set; } = null!;

    public double MontoServicio { get; set; }

    public virtual ICollection<Soporte> Soportes { get; set; } = new List<Soporte>();
}
