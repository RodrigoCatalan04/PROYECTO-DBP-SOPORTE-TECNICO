﻿using System;
using System.Collections.Generic;

namespace ProyectoDBP_ServicioTecnico.Models;

public partial class Admin
{
    public int IdAdmin { get; set; }

    public string Usuario { get; set; } = null!;

    public string Contraseña { get; set; } = null!;
}
