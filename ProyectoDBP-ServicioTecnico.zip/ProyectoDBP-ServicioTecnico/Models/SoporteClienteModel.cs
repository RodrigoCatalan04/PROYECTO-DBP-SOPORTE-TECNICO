﻿using System;
using System.Collections.Generic;

namespace ProyectoDBP_ServicioTecnico.Models;

public partial class SoporteClienteModel
{
    public int SoporteClienteModel1 { get; set; }

    public int IdSoporte { get; set; }

    public int IdCliente { get; set; }

    public string NombreCliente { get; set; } = null!;

    public int IdEquipo { get; set; }

    public string DescripcionEquipo { get; set; } = null!;

    public int IdServicio { get; set; }

    public string DescripcionServicio { get; set; } = null!;

    public double MontoSoporte { get; set; }

    public string DescripcionSoporte { get; set; } = null!;

    public string EstadoSoporte { get; set; } = null!;

    public string Solucion { get; set; } = null!;

    public virtual Cliente IdClienteNavigation { get; set; } = null!;

    public virtual Soporte IdSoporteNavigation { get; set; } = null!;
}
