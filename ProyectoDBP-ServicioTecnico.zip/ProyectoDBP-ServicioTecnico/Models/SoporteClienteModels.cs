﻿namespace ProyectoDBP_ServicioTecnico.Models
{
    public class SoporteClienteModels
    {
        public Soporte Soporte { get; set; } 
        public Cliente Cliente { get; set; } 
        public Equipo Equipo { get; set; } 
        public Servicio Servicio { get; set; } 
        public int IdSoporte { get; set; }
        public int IdCliente { get; set; }
        public string NombreCliente { get; set; } = null!;
        public int IdEquipo { get; set; }
        public string DescripcionEquipo { get; set; } = null!;
        public int IdServicio { get; set; }
        public double MontoSoporte { get; set; }
        public string DescripcionSoporte { get; set; } = null!;
        public string EstadoSoporte { get; set; } = null!;

        public string Solucion { get; set; } = null!;
        public string DescripcionServicio { get; set; } = null!;
    }
}