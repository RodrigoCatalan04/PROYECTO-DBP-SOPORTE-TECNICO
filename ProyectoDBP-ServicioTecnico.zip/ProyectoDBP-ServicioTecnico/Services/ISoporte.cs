﻿using ProyectoDBP_ServicioTecnico.Models;

namespace ProyectoDBP_ServicioTecnico.Services
{
    public interface ISoporte
    {
        void addIDCliente(int id);
        void addIDEquipo(int id);
        void addServicio(Servicio servicio);
        IEnumerable<Soporte> GetSoporte();
        void AddSoporte();
        public Soporte BusquedaSoporte(int id);
        void RemoveSoporte(int soporte);
        void EditSoporte(Soporte soporte);
        void addProblema(string p);
        Soporte GetSoporteSolicitud();
        IEnumerable<Soporte> GetSoporteFiltradobyCliente(int id);
    }

}
