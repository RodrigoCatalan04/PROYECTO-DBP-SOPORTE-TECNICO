﻿using ProyectoDBP_ServicioTecnico.Models;

namespace ProyectoDBP_ServicioTecnico.Services
{
    public interface IEquipo
    {
        public void AddEquipo(Equipo c);
        public IEnumerable<Equipo> GetEquipos();
        public Equipo BusquedaEquipo(int id);
        void RemoveEquipo(int id);
        void EditEquipo(Equipo equipo);
    }
}
