﻿using ProyectoDBP_ServicioTecnico.Models;

namespace ProyectoDBP_ServicioTecnico.Services
{
    public interface ICliente
    {
        IEnumerable<Cliente> GetCliente();
        void AddCliente(Cliente c);
        public Cliente BusquedaCliente(int id);
        void RemoveCliente(int cliente);
        void EditCliente(Cliente cliente);
        public bool ValidateCliente(Cliente cliente);
        public Cliente BusquedaClientebyUserPass(string u, string pass);
    }
}
