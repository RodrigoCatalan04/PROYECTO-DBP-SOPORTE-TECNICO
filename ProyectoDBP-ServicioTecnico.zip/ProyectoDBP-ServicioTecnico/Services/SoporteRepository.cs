﻿using ProyectoDBP_ServicioTecnico.Models;

namespace ProyectoDBP_ServicioTecnico.Services
{
    public class SoporteRepository : ISoporte
    {
        private SoporteTecnico conexion = new SoporteTecnico();
        private Soporte objSoporte = new Soporte();
        public void AddSoporte()
        {
            objSoporte.EstadoSoporte = "VIGENTE";
            objSoporte.Solucion = "A ESPERA DE SOLUCIÓN";
            conexion.Soportes.Add(objSoporte);
            conexion.SaveChanges();
        }

        public Soporte BusquedaSoporte(int id)
        {
            var obj = (from tSop in conexion.Soportes
                       where tSop.IdSoporte == id
                       select tSop).Single();
            return obj;
        }
        public void EditSoporte(Soporte soporte)
        {
            var obj = (from tSop in conexion.Soportes
                       where tSop.IdSoporte == soporte.IdSoporte
                       select tSop).FirstOrDefault();
            obj.EstadoSoporte = soporte.EstadoSoporte;
            obj.Solucion = soporte.Solucion;
            conexion.SaveChanges();
        }

        public IEnumerable<Soporte> GetSoporte()
        {
            return conexion.Soportes;
        }

        public void RemoveSoporte(int soporte)
        {
            var obj = BusquedaSoporte(soporte);
            conexion.Soportes.Remove(obj);
            conexion.SaveChanges();
        }

        public void addIDCliente(int id)
        {
            objSoporte.IdCliente = id;
        }

        public void addIDEquipo(int id)
        {
            objSoporte.IdEquipo = id;
        }

        public void addServicio(Servicio servicio)
        {
            objSoporte.IdServicio = servicio.IdServicio;
            objSoporte.MontoSoporte = servicio.MontoServicio;
        }

        public void addProblema(string p)
        {
            objSoporte.DescripcionSoporte = p;
        }

        public Soporte GetSoporteSolicitud()
        {
            return objSoporte;
        }

        public IEnumerable<Soporte> GetSoporteFiltradobyCliente(int id)
        {
            var listaFiltrada = (from tSop in conexion.Soportes
                       where tSop.IdCliente == id
                       select tSop).ToList();
            return listaFiltrada;
        }
    }
}
