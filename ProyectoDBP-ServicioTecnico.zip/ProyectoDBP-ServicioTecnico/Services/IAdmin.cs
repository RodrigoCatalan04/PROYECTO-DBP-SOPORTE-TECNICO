﻿using ProyectoDBP_ServicioTecnico.Models;

namespace ProyectoDBP_ServicioTecnico.Services
{
    public interface IAdmin
    {
        public bool ValidateAdmin(Admin admin);
    }
}