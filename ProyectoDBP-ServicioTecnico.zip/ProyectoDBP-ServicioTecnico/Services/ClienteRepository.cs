﻿using ProyectoDBP_ServicioTecnico.Models;

namespace ProyectoDBP_ServicioTecnico.Services
{
    public class ClienteRepository : ICliente
    {
        private SoporteTecnico ClienteList =new SoporteTecnico();
        public void AddCliente(Cliente c)
        {
            ClienteList.Clientes.Add(c);
            ClienteList.SaveChanges();
        }

        public Cliente BusquedaCliente(int id)
        {
            var obj = (from tCli in ClienteList.Clientes
                       where tCli.IdCliente == id
                       select tCli).Single();
            return obj;
        }

        public Cliente BusquedaClientebyUserPass(string u, string pass)
        {
            var obj = (from tCli in ClienteList.Clientes
                       where tCli.UserCliente == u
                       && tCli.PasswordCliente == pass
                       select tCli).Single();
            return obj;
        }

        public void EditCliente(Cliente cliente)
        {
            var obj = (from tCli in ClienteList.Clientes
                       where tCli.IdCliente == cliente.IdCliente
                       select tCli).FirstOrDefault();
            obj.NombreCliente = cliente.NombreCliente;
            obj.ApellidoCliente = cliente.ApellidoCliente;
            obj.DniCliente = cliente.DniCliente;
            obj.TelefonoCliente = cliente.TelefonoCliente;
            obj.DireccionCliente = cliente.DireccionCliente;
            obj.UserCliente = cliente.UserCliente;
            obj.PasswordCliente = cliente.PasswordCliente;
            ClienteList.SaveChanges();
        }

        public IEnumerable<Cliente> GetCliente()
        {
            return ClienteList.Clientes;
        }

        public void RemoveCliente(int cliente)
        {
            var obj = BusquedaCliente(cliente);
            ClienteList.Clientes.Remove(obj);
            ClienteList.SaveChanges();
        }
        public bool ValidateCliente(Cliente cliente)
        {
            var obj = (from tCli in ClienteList.Clientes
                       where tCli.UserCliente == cliente.UserCliente
                       && tCli.PasswordCliente == cliente.PasswordCliente
                       && tCli.NombreCliente == cliente.NombreCliente
                       && tCli.ApellidoCliente == cliente.ApellidoCliente
                       && tCli.DireccionCliente == cliente.DireccionCliente
                       && tCli.DniCliente == cliente.DniCliente
                       && tCli.TelefonoCliente == cliente.TelefonoCliente
                       select tCli).FirstOrDefault();
            if (obj == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
