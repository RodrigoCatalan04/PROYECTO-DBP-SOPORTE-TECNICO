﻿using ProyectoDBP_ServicioTecnico.Models;

namespace ProyectoDBP_ServicioTecnico.Services
{
    public class EquipoRepository : IEquipo
    {
        private SoporteTecnico EquipoConexion = new SoporteTecnico();
        public void AddEquipo(Equipo c)
        {
            EquipoConexion.Equipos.Add(c);
            EquipoConexion.SaveChanges();
        }

        public Equipo BusquedaEquipo(int id)
        {
            var obj = (from tEqui in EquipoConexion.Equipos
                       where tEqui.IdEquipo == id
                       select tEqui).Single();
            return obj;
        }

        public void EditEquipo(Equipo equipo)
        {
            var obj = (from tEqui in EquipoConexion.Equipos
                       where tEqui.IdEquipo == equipo.IdEquipo
                       select tEqui).FirstOrDefault();
            obj.DescripcionEquipo = equipo.DescripcionEquipo;
            EquipoConexion.SaveChanges();
        }

        public IEnumerable<Equipo> GetEquipos()
        {
            return EquipoConexion.Equipos;
        }

        public void RemoveEquipo(int id)
        {
            var obj = BusquedaEquipo(id);
            EquipoConexion.Equipos.Remove(obj);
            EquipoConexion.SaveChanges();
        }
    }
}
