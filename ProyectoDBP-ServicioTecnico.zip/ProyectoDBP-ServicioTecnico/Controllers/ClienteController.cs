﻿using Microsoft.AspNetCore.Mvc;
using ProyectoDBP_ServicioTecnico.Models;
using ProyectoDBP_ServicioTecnico.Services;
using Newtonsoft.Json;

namespace ProyectoDBP_ServicioTecnico.Controllers
{
    public class ClienteController : Controller
    {
        private readonly ICliente _cliente;
        private readonly IEquipo _equipo;
        private readonly IServicio _servicio;
        private readonly ISoporte _soporte;
        public ClienteController(ICliente cliente, IEquipo equipo, IServicio servicio, ISoporte soporte)
        {
            _cliente = cliente;
            _equipo = equipo;
            _servicio = servicio;
            _soporte = soporte;
        }

        [Route("/")]
        [Route("Cliente/Principal")]
        public IActionResult Principal()
        {
            return View();
        }

        [Route("Cliente/Ingreso")]
        public IActionResult Ingreso()
        {
            return View();
        }
        [Route("Cliente/Registro")]
        public IActionResult Registro()
        {
            return View();
        }
        public IActionResult Cerrar()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Ingreso");
        }
        public IActionResult AgregarCliente(Cliente cliente)
        {
            _cliente.AddCliente(cliente);
            return RedirectToAction("Ingreso");
        }
        public IActionResult Validacion(string usuario, string contraseña)
        {
            var objCliente = _cliente.BusquedaClientebyUserPass(usuario, contraseña);
            if (_cliente.ValidateCliente(objCliente) == true)
            {
                _soporte.addIDCliente(objCliente.IdCliente);
                HttpContext.Session.SetString("ClienteSoporte", JsonConvert.SerializeObject(objCliente));
                HttpContext.Session.SetInt32("IdCliente", objCliente.IdCliente);
                return RedirectToAction("ClienteSolicitudes");
            }
            else
            {
                return RedirectToAction("Ingreso");
            }
        }
        [Route("Cliente/ClienteSolicitudes")]
        public IActionResult ClienteSolicitudes()
        {
            var objCliente = HttpContext.Session.GetString("ClienteSoporte");
            if (objCliente != null)
            {
                var idCliente = HttpContext.Session.GetInt32("IdCliente");

                // Obtén los datos de Soporte, Cliente y Equipo
                var listSoporte = _soporte.GetSoporteFiltradobyCliente(idCliente.Value);
                var cliente = _cliente.BusquedaCliente(idCliente.Value);
                var equipos = _equipo.GetEquipos();
                var serviciosList = _servicio.GetServicio();

                // Combina los datos en una lista de modelos SoporteClienteModel
                var listSoporteClienteModel = new List<SoporteClienteModels>();
                foreach (var soporte in listSoporte)
                {
                    var servicio = serviciosList.FirstOrDefault(s => s.IdServicio == soporte.IdServicio);
                    var equipo = equipos.FirstOrDefault(e => e.IdEquipo == soporte.IdEquipo);
                    var soporteClienteModel = new SoporteClienteModels
                    {
                        Soporte = soporte,
                        Cliente = cliente,
                        Equipo = equipo,
                        Servicio = servicio
                    };
                    listSoporteClienteModel.Add(soporteClienteModel);
                }

                return View(listSoporteClienteModel);
            }
            else
            {
                return RedirectToAction("Ingreso");
            }

            //          var objCliente = HttpContext.Session.GetString("ClienteSoporte");
            //           if (objCliente != null)
            //         {
            //             var idCliente = HttpContext.Session.GetInt32("IdCliente");
            //             var list = _soporte.GetSoporteFiltradobyCliente(idCliente.Value);
            //           return View(list);
            //       }
            //       else
            //      {
            //            return RedirectToAction("Ingreso");
            //       }
        }

        [Route("Cliente/ClienteTabla")]
        public IActionResult ClienteTabla()
        {
            return View(_equipo.GetEquipos());
        }

        [Route("Cliente/ServiciodelEquipo")]
        public IActionResult ServiciodelEquipo(int seleccion)
        {
            _soporte.addIDEquipo(seleccion);
            return View(_servicio.GetServicio());
        }

        [Route("Cliente/AgregarNuevoProducto")]
        public IActionResult AgregarNuevoProducto()
        {
            return View();
        }

        public IActionResult AgregarProducto(Equipo eq)
        {
            _equipo.AddEquipo(eq);
            return RedirectToAction("ClienteTabla");
        }

        [Route("Cliente/Eliminar/{codigo}")]
        public IActionResult Eliminar(int codigo)
        {
            _equipo.RemoveEquipo(codigo);
            return RedirectToAction("ClienteTabla");
        }

        [Route("Cliente/ClienteSolicitud")]
        public IActionResult ClienteSolicitud(int Tipo, string Problema)
        {

            var obj = _servicio.ServicioById(Tipo);
            _soporte.addServicio(obj);
            _soporte.addProblema(Problema);

            var soporte = _soporte.GetSoporteSolicitud(); // Obtener el objeto Soporte necesario
            var cliente = _cliente.BusquedaCliente(soporte.IdCliente); // Obtener el objeto Cliente necesario
            var equipo = _equipo.BusquedaEquipo(soporte.IdEquipo); // Obtener el primer equipo de la lista
            var servicio = obj;

            var soporteClienteModel = new SoporteClienteModels
            {
                Soporte = soporte,
                Cliente = cliente,
                Equipo = equipo,
                Servicio = servicio,
                // asignar los demás valores necesarios en el modelo
            };

            return View(soporteClienteModel);
        }
        [Route("Cliente/AgregarSoporte")]
        public IActionResult AgregarSoporte(Soporte soporte)
        {
            _soporte.AddSoporte();
            return RedirectToAction("ClienteSolicitudes");
        }

        [Route("Cliente/FILTRADOCLIENTE")]
        public IActionResult FILTRADOCLIENTE()
        {
            return View(_cliente.GetCliente());
        }

        [Route("Cliente/TABLACLIENTEFILTRADO")]
        public IActionResult TABLACLIENTEFILTRADO(int Tipo)
        {
            var list = new List<SoporteClienteModels>();
            var ObjCLI = _cliente.BusquedaCliente(Tipo);
            var listSoporte = _soporte.GetSoporteFiltradobyCliente(Tipo);
            var c = new Class
            {
                c = ObjCLI,
            lst = listSoporte,
            };
            return View(c);
        }

    }
}
