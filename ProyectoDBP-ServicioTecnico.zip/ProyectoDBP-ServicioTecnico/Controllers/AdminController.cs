﻿using Microsoft.AspNetCore.Mvc;
using ProyectoDBP_ServicioTecnico.Models;
using Newtonsoft.Json;
using ProyectoDBP_ServicioTecnico.Services;

namespace ProyectoDBP_ServicioTecnico.Controllers
{
    public class AdminController : Controller
    {
        private readonly ICliente _cliente;
        private readonly IServicio _servicio;
        private readonly IAdmin _admin;
        private readonly ISoporte _soporte;
        private readonly IEquipo _equipo;
        public AdminController(IServicio servicio, IAdmin admin, ISoporte soporte, ICliente cliente, IEquipo equipo)
        {
            _servicio = servicio;
            _admin = admin;
            _soporte = soporte;
            _cliente = cliente;
            _equipo = equipo;
        }
        [Route("Admin/Nuevo")]
        public IActionResult Nuevo()
        {
            return View();
        }
        public IActionResult Grabar(Servicio servicio)
        {
            _servicio.AddServicio(servicio);
            return RedirectToAction("AdminTablaServicios");
        }

        [Route("Admin/Ingreso")]
        public IActionResult Ingreso()
        {
            return View();
        }
        public IActionResult Validacion(Admin admin)
        {
            if (_admin.ValidateAdmin(admin) == true)
            {
                HttpContext.Session.SetString("AdminSoporte",JsonConvert.SerializeObject(admin));
                return RedirectToAction("AdminTabla");
            }
            else
            {
                return RedirectToAction("Ingreso");
            }
        }

        [Route("Admin/AdminTabla")]
        public IActionResult AdminTabla()
        {

            var objA = HttpContext.Session.GetString("AdminSoporte");
            if (objA != null)
            {

                // Obtén los datos de Soporte, Cliente y Equipo
                var listSoporte = _soporte.GetSoporte();
                var cliente = _cliente.GetCliente().ToList();
                var equipos = _equipo.GetEquipos();
                var serviciosList = _servicio.GetServicio();

                // Combina los datos en una lista de modelos SoporteClienteModel
                var listSoporteClienteModel = new List<SoporteClienteModels>();
                foreach (var soporte in listSoporte)
                {
                    
                    var servicio = serviciosList.FirstOrDefault(s => s.IdServicio == soporte.IdServicio);
                    var equipo = equipos.FirstOrDefault(e => e.IdEquipo == soporte.IdEquipo);
                    var c = cliente.FirstOrDefault(e => e.IdCliente == soporte.IdCliente);
                    var soporteClienteModel = new SoporteClienteModels
                    {
                        Soporte = soporte,
                        Cliente = c,
                        Equipo = equipo,
                        Servicio = servicio
                    };
                    listSoporteClienteModel.Add(soporteClienteModel);
                }

                return View(listSoporteClienteModel);
            }
            else
            {
                return RedirectToAction("Ingreso");
            }
        }
        public IActionResult AdminTablaServicios()
        {
            return View(_servicio.GetServicio());
        }


        [Route("Admin/Eliminar/{codigo}")]
        public IActionResult Eliminar(int codigo)
        {
            _servicio.remove(codigo);
            return RedirectToAction("AdminTablaServicios");
        }
        [Route("Admin/Modificar/{codigo}")]
        public IActionResult Modificar(int codigo)
        {
            var objAModificar = _servicio.ServicioById(codigo);
            return View(objAModificar);
        }
        [Route("Admin/ModificarService")]
        public IActionResult ModificarService(Servicio obj)
        {
            _servicio.editDetails(obj);
            return RedirectToAction("AdminTablaServicios");
        }
        public IActionResult Cerrar()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Ingreso");
        }
        [Route("Admin/AtenderSolicitud/{codigo}")]
        public IActionResult AtenderSolicitud(int codigo)
        {
            var objAtender = _soporte.BusquedaSoporte(codigo);
            return View(objAtender);
        }
        [Route("Admin/ModificarSoporte")]
        public IActionResult ModificarSoporte(Soporte obj)
        {
            _soporte.EditSoporte(obj);
            return RedirectToAction("AdminTabla");
        }
    }
}
