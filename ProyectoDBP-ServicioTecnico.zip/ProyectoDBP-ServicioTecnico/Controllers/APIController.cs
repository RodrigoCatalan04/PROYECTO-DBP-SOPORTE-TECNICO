﻿using Microsoft.AspNetCore.Mvc;
using ProyectoDBP_ServicioTecnico.Models;
using ProyectoDBP_ServicioTecnico.Services;

namespace ProyectoDBP_ServicioTecnico.Controllers
{
    [Route("Api/[Controller]")]
    [ApiController]
    public class APIController : Controller
    {
        private readonly IServicio _servicio;
        private readonly IAdmin _admin;
        private readonly ISoporte _soporte;
        public APIController(IServicio servicio, IAdmin admin, ISoporte soporte)
        {
            _servicio = servicio;
            _admin = admin;
            _soporte = soporte;
        }
        [HttpGet("ListarSoporte")]
        public IActionResult GetSoporte()
        {
            return Ok(_soporte.GetSoporte());
        }
        [HttpGet("BuscarSoporte/{id}")]
        public IActionResult GetSoporte(int id)
        {
            var obj = _soporte.BusquedaSoporte(id);
            if (obj != null)
            {
                var error = NotFound("El soporte de codigo " + id.ToString() + " No existe");
                return error;
            }
            else
            {
                return Ok(obj);
            }
            
        }
        [HttpPost("AgregarSoporte")]
        public IActionResult AddSoporte(Soporte s)
        {
            var objService = _servicio.ServicioById(s.IdServicio);
            _soporte.addIDCliente(s.IdCliente);
            _soporte.addIDEquipo(s.IdEquipo);
            _soporte.addProblema(s.DescripcionSoporte);
            _soporte.addServicio(objService);
            
            _soporte.AddSoporte();
            return CreatedAtAction(nameof(AddSoporte), s);
        }
        [HttpDelete("EliminarSoporte/{id}")]
        public IActionResult DeleteSoporte(int id) 
        {
            _soporte.RemoveSoporte(id);
            return NoContent();
        }
        [HttpPut("UpdateSoporte")]
        public IActionResult UpdateSoporte(Soporte s)
        {
            _soporte.EditSoporte(s);
            return CreatedAtAction(nameof(UpdateSoporte), s);
        }


        [HttpGet("ListarServicio")]
        public IActionResult GetServicio()
        {
            return Ok(_servicio.GetServicio());
        }
        [HttpGet("BuscarServicio/{id}")]
        public IActionResult GetServicio(int id)
        {
            var obj = _servicio.ServicioById(id);
            if (obj != null)
            {
                var error = NotFound("El servicio de codigo " + id.ToString() + " No existe");
                return error;
            }
            else
            {
                return Ok(obj);
            }

        }
        [HttpPost("AgregarServicio")]
        public IActionResult AddServicio(Servicio s)
        {
            _servicio.AddServicio(s);
            return CreatedAtAction(nameof(AddServicio), s);
        }
        [HttpDelete("EliminarServicio/{id}")]
        public IActionResult DeleteServicio(int id)
        {
            _servicio.remove(id);
            return NoContent();
        }
        [HttpPut("UpdateServicio")]
        public IActionResult UpdateServicio(Servicio s)
        {
            _servicio.editDetails(s);
            return CreatedAtAction(nameof(UpdateServicio), s);
        }
        [HttpPost("ValidateAdmin")]
        public IActionResult ValidateAdmin(Admin admin)
        {
            bool Validacion = _admin.ValidateAdmin(admin);

            if (Validacion == true)
            {
                return Ok("Admin válido");
            }
            else
            {
                return Unauthorized("Admin inválido");
            }
        }



    }
}   
