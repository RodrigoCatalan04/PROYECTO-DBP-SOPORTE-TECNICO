﻿function cambioEstado(radio) {
    var estadoInput = document.getElementById('estadoSoporte');
    estadoInput.value = radio.value;
}