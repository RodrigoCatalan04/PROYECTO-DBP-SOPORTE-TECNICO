﻿document.getElementById("tipo").addEventListener("change", function (event) {
    event.preventDefault();
    let tipo = document.getElementById("tipo").value;
    let problema = document.getElementById("problema");
    problema.value = "";
    if (tipo == "Mantenimiento") {
        problema.value = "Mantenimiento preventivo";
        problema.disabled = true;
    } else {
        problema.disabled = false;
    }
}, false);